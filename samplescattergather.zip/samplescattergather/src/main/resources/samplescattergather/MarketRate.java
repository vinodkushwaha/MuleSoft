package samplescattergather;

import org.mule.api.MuleEvent;

public class MarketRate {
	
	MuleEvent event;
	String MarketName;
	Integer MarketRate;
	public MuleEvent getEvent() {
		return event;
	}
	public void setEvent(MuleEvent event) {
		this.event = event;
	}
	public String getMarketName() {
		return MarketName;
	}
	public void setMarketName(String marketName) {
		MarketName = marketName;
	}
	public Integer getMarketRate() {
		return MarketRate;
	}
	public void setMarketRate(Integer marketRate) {
		MarketRate = marketRate;
	}

}
