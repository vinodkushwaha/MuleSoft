package com.capg;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class GratuityService {
	
	
/*	public static void main(String[] args) {
		getEligibility("10/09/2010");
	}*/

	public static boolean getEligibility(String doj) {

		Date dojStr;
		boolean flag = false;
		try {
			dojStr = new SimpleDateFormat("dd/MM/yyyy").parse(doj);

			Date currentdate = Calendar.getInstance().getTime();

			long duration = currentdate.getTime() - dojStr.getTime();
			
			if(duration > 5){
				System.out.println("eligible for Gratuity fund");
				flag = true;
			} else{
				System.out.println("Not eligible for Gratuity fund");
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;

	}

}
