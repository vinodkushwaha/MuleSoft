package javainteceptor;

import org.mule.api.MuleEvent;
import org.mule.api.MuleException;
import org.mule.api.interceptor.Interceptor;
import org.mule.processor.AbstractInterceptingMessageProcessor;

public class MyInterceptor extends AbstractInterceptingMessageProcessor implements Interceptor {

	@Override
	public MuleEvent process(MuleEvent event) throws MuleException {
		System.out.println("MyInterceptor.process()");
		//String payload = (String)event.getMessage().getPayload();
        event.getMessage().setPayload(event.getMessage().getPayload() + "!7888888");
       return processNext(event);
	}

}
