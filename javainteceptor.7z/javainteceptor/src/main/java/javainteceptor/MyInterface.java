package javainteceptor;

public interface MyInterface {
	
	void draw();

}
