package javainteceptor;

public class Sample implements MyInterface{

	@Override
	public void draw() {
		System.out.println("Sample.draw()");
		
	}
	
}
