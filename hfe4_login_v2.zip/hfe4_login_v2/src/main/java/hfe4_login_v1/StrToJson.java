package hfe4_login_v1;

import org.json.JSONException;
import org.json.JSONObject;

public class StrToJson {
	
/*	public static void main(String[] args) {
		convert(" {\"UserName\":\"vinod\",\"EmailId\":\"kush@gmail.com\",\"Password\":\"Welcome@21\",\"Gender\":\"M\",\"AccountType\":\"Current Account\" ,\"Dob\":\"2019-09-09\"}");
		

	}*/
	public   JSONObject convert(String input){
		
		System.out.println("StrToJson.convert() :" + input);
		
		 JSONObject jsonObj = null;
		 
		 
		try {
			
			if( input != null){
				jsonObj = new JSONObject(input);
				System.out.println("final op :  " +jsonObj);
			}
			
		} catch (JSONException e) {
			
			e.printStackTrace();
		}
		
		 
		 
		return jsonObj;
		
	}

}
