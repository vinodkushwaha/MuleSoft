package hfe4_login;

public class Checkuser {
	
	public boolean userStatus(String payload){
		boolean flag = false;
		System.out.println("Checkuser.userStatus()");
		System.out.println("payload :" + payload );
		
		return flag;
		
	}

}
